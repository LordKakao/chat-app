package org.sparklogy.chatroom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatroomApplicationTests {

	@Test
	void contextLoads() {
	}

}
