rootProject.name = "weather-service"
