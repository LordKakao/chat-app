package org.sparklogy.weatherservice;

import lombok.RequiredArgsConstructor;
import org.apache.coyote.BadRequestException;
import org.sparklogy.weatherservice.model.WeatherInfoResponse;
import org.sparklogy.weatherservice.model.WttrResponse;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Service
@RequiredArgsConstructor
public class WeatherService {
    public static final String WEATHER_API_URL = "https://wttr.in";
    private final WebClient webClient;

    public WeatherInfoResponse getWeather(String city) throws BadRequestException {
        WttrResponse response = webClient.get()
                .uri("/{city}?format=j1", city)
                .retrieve()
                .bodyToMono(WttrResponse.class)
                .block();

        if (response == null) {
            throw new BadRequestException("Unable to fetch weather");
        }

        WttrResponse.CurrentCondition weather = response.getCurrentCondition().getFirst();
        WttrResponse.NearestArea area = response.getNearestArea().getFirst();

        return WeatherInfoResponse.builder()
                .location(area.getAreaName().getFirst().getValue())
                .temperatureCelsius(weather.getTemp())
                .description(weather.getWeatherDesc().stream()
                        .map(WttrResponse.WeatherDesc::getValue).toList()
                )
                .build();
    }
}
